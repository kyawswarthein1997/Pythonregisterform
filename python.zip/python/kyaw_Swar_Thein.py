#! c:\Python36-32\python.exe
import MySQLdb as mysql
import cgi
import cgitb;cgitb.enable()

print("Content-type:text/html\n\n")
db = mysql.connect("localhost", user="root", password="admin", db="m8_oop_registeration_form_kyaw_swar_thein")
cursor = db.cursor()
form=cgi.FieldStorage()
def m8_oop_registeration_form_kyaw_swar_thein(fieldname):
    if fieldname in form:
        return form[fieldname].value
if "submitted" in form:
  firstname=m8_oop_registeration_form_kyaw_swar_thein("first_name")
  lastname=m8_oop_registeration_form_kyaw_swar_thein("last_name")
  email=m8_oop_registeration_form_kyaw_swar_thein("email")
  gender=m8_oop_registeration_form_kyaw_swar_thein("gender")
  address=m8_oop_registeration_form_kyaw_swar_thein("address")
  phone=m8_oop_registeration_form_kyaw_swar_thein("phone")
  course=m8_oop_registeration_form_kyaw_swar_thein("Course")

  try:
    cursor.execute("insert into studentmaster(FirstName, LastName, Email, Gender, Residental_Address, Contact_No, Course_Id) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}')".format(firstname,lastname,email,gender,address,phone,course))
    print("""
<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Thank You Page</title>
  <script src="https://bootstrapcreative.com/wp-bc/wp-content/themes/wp-bootstrap/codepen/bootstrapcreative.js?v=1"></script>
  
  <link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.5/css/bootstrap.min.css'>

  
  
</head>

<body>

  <div class="jumbotron text-xs-center">
  <h1 class="display-3"> <span style="color:red" > Thank You! </span> </h1>
 <p Class="display-3"> For Your Registeration in </p> 
 <p class="display-3" style="color:#538b01; font-weight:bold; font-style:italic;">ABC Learning Center </p>
  <p class="lead"><strong>Please check your email for confirmation.</strong> </p>
  <hr>
 
  <p class="lead">
    <a class="btn btn-primary btn-sm" href="registeration_form.py" role="button">Continue to ABC Register Page</a>
  </p>
  <iframe src="https://giphy.com/embed/95P1vO6r7rsk0" width="480" height="270" frameBorder="0" class="giphy-embed" allowFullScreen></iframe><p><a href="https://giphy.com/gifs/thank-you-95P1vO6r7rsk0">via GIPHY</a></p>
</div>


</body>

</html>
""")

    db.commit()
  except Exception as e:
    db.rollback()
    print(str(e))
    print("Error occured")
db.close()
