#! c:\Python36-32\python.exe
import MySQLdb as mysql
import cgi
import cgitb;cgitb.enable()
print("Content-type:text/html\n\n")
form=cgi.FieldStorage()

#defining connect to database as a function
def connect_db() :
    db = mysql.connect(host= "localhost",user="root",password="admin",database="m8_oop_registeration_form_kyaw_swar_thein")
    return db

def show_courses():
    cursor.execute("select CourseId, Course_Name from coursemaster")
    row = cursor.fetchone()
    while row is not None:
        row = cursor.fetchone()
db=connect_db()
cursor=db.cursor()
show_courses()

print("""
<!DOCTYPE html>
<html lang="en">
<head>
	<title>ABC Registration Form</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body style="background-color: #999999;">
	
	<div class="limiter">
		<div class="container-login100">
			<div class="login100-more" style="background-image: url('images/abc.jpg');"></div>

			<div class="wrap-login100 p-l-50 p-r-50 p-t-72 p-b-50">
				<form name="registeraton" action="kyaw_Swar_Thein.py" onsubmit ="return ValidationForm()" method="post" class="login100-form validate-form" role="form">
					<span class="login100-form-title p-b-59">
						ABC Student Registration Form 
					</span>
					<!--Name Text Box-->
					<div class="wrap-input100 validate-input" data-validate="First Name is required">
						<span class="label-input100">First Name</span>
						<input  class="input100"  onkeypress="return alphaOnly(event)" type="text" maxlength="50" name="first_name" placeholder="First Name">
						<a target="_blank" title="First Name will allow only alphabateical and the word should below 50, thanks!"><img src="https://shots.jotform.com/kade/Screenshots/blue_question_mark.png" height="13px"/></a>
						<span class="focus-input100"></span>
					</div>
					<!--Name Text Box-->
					<div class="wrap-input100 validate-input" data-validate="Last Name is required">
						<span class="label-input100">Last Name</span>
						<input class="input100"  onkeypress="return alphaOnly(event)" type="text" maxlength="50" name="last_name" placeholder="Last Name">
						<a target="_blank" href="#" title="Last Name will allow only alphabateical and the word should below 50,thanks"><img src="https://shots.jotform.com/kade/Screenshots/blue_question_mark.png" height="13px"/></a>
						<span class="focus-input100"></span>
					</div>
					<!-- Email Text Box-->	
					<div class="wrap-input100 validate-input" data-validate = "Valid email is required: ex@abc.xyz">
						<span class="label-input100">Email</span>
						<input class="input100"  type="textarea" maxlength="30" name="email" placeholder="Email address...">
						<a target="_blank" href="#" title="Email will allow both number and alpha the gmail should below 30 words thanks!"><img src="https://shots.jotform.com/kade/Screenshots/blue_question_mark.png" height="13px"/></a>
						<span class="focus-input100"></span>
					</div>
					
					<!-- Gender Radion Button-->
					<div class="wrap-input100 validate-input" data-validate = "Gender is required" >
					
					<label for="Phone" class="control-label">Gender</label><br>
					<input type="radio" name="gender" value="Male" class="gender" id="gd" onblur="chkblnk('gd','error6')"> Male
					<input type="radio" name="gender" value="Female" class="gender"> Female
					<div id="error6" class="validate-input" style="background-color:purple; color:white;"></div>
					</div>
					
					<!-- Residental Address text area-->
					<div class="wrap-input100 validate-input" data-validate = "Address is required">
						<span class="label-input100">Residental Address</span>
						
						<input class="input100"  type="textarea" maxlength="225" name="address" placeholder="Address">
						<a target="_blank" href="#" title="Please Fill up the Address, thanks!"><img src="https://shots.jotform.com/kade/Screenshots/blue_question_mark.png" height="13px"/></a>
						<span class="focus-input100"></span>
					</div>
					
					<!-- phone Number Box-->	
					<div class="wrap-input100 validate-input" data-validate = "Valid phone number is required: 123-456-789-">
						<span class="label-input100">Phone</span>
						<input class="input100"  onkeypress="return isNumberKey(event)" type="text" maxlength="11" name="phone" placeholder="Phone Number">
						<a target="_blank" href="#" title="Contact number can only allow numbers only and the maximum number is 11, thanks!"><img src="https://shots.jotform.com/kade/Screenshots/blue_question_mark.png" height="13px"/></a>
						<span class="focus-input100"></span>
					</div>
					
					<!-- Courses drop down box-->	
					<div class="wrap-input100 validate-input" data-validate = "course selection is required">
					<div class="form-group">
					<label class="col-sm-3 control-label">Courses</label>
					<div class="row">
						<div class="col-10">
							<select  type="text" value="" name="Course" class="form-control"  >
""")
for (CourseId,Course_Name) in cursor:
    print ('<option value="' + str(CourseId) +'">' + Course_Name + '</option> ')
print("""
						</select>
							<div id="error8" class="validate-input" style="background-color:purple; color:white;"></div>
						</div>
						
					</div>
					</div>
					<div class="col" style="color:red" id="error8"></div>	 
						
						<a target="_blank" href="#" title="Please Choose any one Courses, thanks!"><img src="https://shots.jotform.com/kade/Screenshots/blue_question_mark.png" height="13px"/></a>
						<span class="focus-input100"></span>
					</div>
					
					

					<div class="flex-m w-full p-b-33">
						<div class="contact100-form-checkbox">
							
								<span class="txt1">
									
									<a href="#" class="txt2 hov1">
									
									</a>
								</span>
							
						</div>

						
					</div>

					<div class="container-login100-form-btn">
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
							<input type="hidden" name="submitted" value="1">
							
							<button class="login100-form-btn gender" onClick="ValidateForm(this.form)" type="submit" name="SubmitButton" value="submit">
								submit
							</button>
						</div>
						<br><br>
						
						
						
						<input type="hidden" name="submitted" value="1">
						<input type="reset" value="Clear" class="btn btn-inf0">
							
						
					</div>
				</form>
			</div>
		</div>
	</div>
	
<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>
<!--===============================================================================================-->
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
	 crossorigin="anonymous"></script>
<!--===============================================================================================-->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
	 crossorigin="anonymous"></script>
<!--===============================================================================================-->
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
	 crossorigin="anonymous"></script>
<!--===============================================================================================-->
	
	<!--Only number For phone Number-->
<SCRIPT language=Javascript>
      <!--
      function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
      //-->
   </SCRIPT>

   <!--Only Letter-->
   <SCRIPT language=Javascript>
  function alphaOnly(evt) {
    var charCode = (evt.which) ? evt.which : window.event.keyCode;

    if (charCode <= 13) {
        return true;
    }
    else {
        var keyChar = String.fromCharCode(charCode);
        var re = /^[a-zA-Z]+$/
        return re.test(keyChar);
    }
}
</script>
<!--Gender validation-->
  <SCRIPT language=Javascript>
	  function ValidateForm(form) {
                ErrorText = "";
                if ((form.gender[0].checked == false) && (form.gender[1].checked == false)) {
                    document.getElementById("error6").innerHTML = "Please select gender";
                } else {
                    document.getElementById("error6").innerHTML = "";
                }
            }

</script>
<!--courses validation-->			
 <SCRIPT language=Javascript>			
	 function Validate()
{
var  what =  document.forms["RegForm"]["course"]; 
if (what.selectedIndex < 1)                  
    { 
        alert("Please enter your course."); 
        what.focus(); 
        return false; 
    } 
   
    return true; 
}
 </SCRIPT>
 <!-- Auto Updating Copyright Script created with Rapid Purple Webmaster Tools (http://rapidpurple.com). -->
<script language="JavaScript">
<!--
function y2k(number) { return (number < 1000) ? number + 1900 : number; }
var today = new Date();
var year = y2k(today.getYear());
document.write('© '+year+' Kyaw Swar Thein - All Rights Reserved');
//-->
</script>


</body>
</html>

""")

